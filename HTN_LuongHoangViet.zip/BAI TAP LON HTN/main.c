#include<16F877A.h>
#fuses NOWDT, XT, NOPUT, NOPROTECT, NOCPD, NOBROWNOUT, NOLVP, NOCPD, NOWRT, NODEBUG
#use delay(clock=20M)
#use I2C(MASTER, I2C1, SLOW = 100000, STREAM = DS1307_STREAM)
#include <DS1307.c>  
#define LCD_RS_PIN PIN_B0
#define LCD_RW_PIN PIN_B1
#define LCD_ENABLE_PIN PIN_B2
#define LCD_DATA4 PIN_B4
#define LCD_DATA5 PIN_B5
#define LCD_DATA6 PIN_B6
#define LCD_DATA7 PIN_B7
#include<lcd.c>
unsigned int16 Future,Gio,Phut,Giay,Ngay,Thang,Nam,maphim;
unsigned int16 N1,N2,N3,N4,N5,N6;
unsigned int8  i,ctrl_Menu,LOOP, BT[2]={0,0};
unsigned int16 GioBT[2]={0,0},PhutBT[2]={0,0};
RTC_Time *mytime;
void lcd_clear()
{
      lcd_send_byte(0,1);
      delay_ms(2);
      #if defined(LCD_EXTENDED_NEWLINE)
      g_LcdX=0;
      g_LcdY=0;
      #endif
}
unsigned int8 quet_phim()
{
   unsigned int8 hang, mp=0xff;
   unsigned int8 maquet[4]={0xFE, 0xFD, 0xFB, 0xF7};
   for(hang=0; hang<=3; hang++)
   {
      output_D(maquet[hang]);
      while(input(pin_D4)==0) mp=hang*4+1;
      while(input(pin_D5)==0) mp=hang*4+2; 
      while(input(pin_D6)==0) mp=hang*4+3;
      while(input(pin_D7)==0) mp=hang*4+4;
   }
   return mp;
}
void Menu_case()
{
   switch (ctrl_Menu)
   {
      case 1:
      {
         lcd_gotoxy(1, 1);
         lcd_putc(">");
         lcd_gotoxy(1, 2);
         lcd_putc(" ");
         break;
      }
      case 2:
      {
         lcd_gotoxy(1, 1);
         lcd_putc(" ");
         lcd_gotoxy(1, 2);
         lcd_putc(">");
         break;
      }
   }
}
void show_Time()
{
   lcd_gotoxy(1, 1);
   lcd_putc("TIME: ");
   lcd_gotoxy(7, 1); 
   printf(lcd_putc, "%01ld%01ld:%01ld%01ld:%01ld%01ld", N1,N2,N3,N4,N5,N6);
}

void show_BT()
{
   lcd_gotoxy(1, 1);
   lcd_putc("TIME: ");
   lcd_gotoxy(7, 1); 
   printf(lcd_putc, "%01ld%01ld:%01ld%01ld", N1,N2,N3,N4);
}
void show_Date()
{
   lcd_gotoxy(1, 1);
   lcd_putc("DATE: ");
   lcd_gotoxy(7, 1); 
   printf(lcd_putc, "20%01ld%01ld/%01ld%01ld/%01ld%01ld", N1,N2,N3,N4,N5,N6);
}

int16 DichPhim(int16 i)
{
   switch (i)
   {
      case 1:
      {
         return 1;
         break;
      }
      case 2:
      {
         return 2;
         break;
      }
      case 3:
      {
         return 3;
         break;
      }
      case 5:
      {
         return 4;
         break;
      }
      case 6:
      {
         return 5;
         break;
      }
      case 7:
      {
         return 6;
         break;
      }
      case 9:
      {
         return 7;
         break;
      }
      case 10:
      {
         return 8;
         break;
      }
      case 11:
      {
         return 9;
         break;
      }
      case 14:
      {
         return 0;
         break;
      }
   }
}

void SET_TIME()
{
   delay_ms(500);
   LOOP=1;
   maphim=0xff;
   N1=0,N2=0,N3=0,N4=0,N5=0,N6=0;
   while (LOOP==1&&maphim!=16){
      show_Time();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim == 14){
         N1=DichPhim(maphim);
      }
      if (maphim==4){
         LOOP=0;
      }
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1&&maphim!=16){
      show_Time();
      maphim=quet_phim();
      if (N1==0 || N1==1){
         if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11 || maphim==14){
            N2=DichPhim(maphim);
         }
      }
      if (N1 == 2){
         if (maphim==1 || maphim==2 || maphim==3 || maphim == 14){
            N2=DichPhim(maphim);
         }
      }
      if (maphim==4){LOOP=0;}
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1&&maphim!=16){
      show_Time();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim == 14){
         N3=DichPhim(maphim);
      }
      
      if (maphim==4){LOOP=0;}
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1 && maphim!=16){
      show_Time();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11 || maphim==14){
         N4=DichPhim(maphim);
      }
      if (maphim==4){LOOP=0;}
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1&&maphim!=16){
      show_Time();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim == 14){
         N5=DichPhim(maphim);
      }
      if (maphim==4){
         LOOP=0;
      }
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1 && maphim!=16){
      show_Time();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11 || maphim==14){
         N6=DichPhim(maphim);
      }
      if (maphim==4){
         LOOP=0;
      }
   }
   if (LOOP==1){
      mytime = RTC_Get();
      Gio=N1*10+N2;
      Phut=N3*10+N4;
      Giay=N5*10+N6;
      mytime->hours = Gio;
      mytime->minutes = Phut;
      mytime->seconds = Giay;
      RTC_Set(mytime);
   }
   else {
      lcd_clear();
      lcd_gotoxy(1, 1);
      lcd_putc("CANCELED");
      delay_ms(2000);
   }
}
void SET_DATE()
{
   LOOP=1;
   N1=0,N2=0,N3=0,N4=1,N5=0,N6=1;
   delay_ms(500);
   while (LOOP==1 && maphim!=16)
   {
      show_Date();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11 || maphim==14)
      {
         N1=DichPhim(maphim);
      }
      
      if (maphim==4)
      {
         LOOP=0;
      }
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1 && maphim!=16)
   {
      show_Date();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11 || maphim==14)
      {
         N2=DichPhim(maphim);
      }
      
      if (maphim==4)
      {
         LOOP=0;
      }
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);Nam=N1*10+N2;}
   while (LOOP==1 && maphim!=16)
   {
      show_Date();
      maphim=quet_phim();
      if (maphim==14)
      {
         N3=DichPhim(maphim);
         N4=1;
      }
      if (maphim==1)
      {
         N3=DichPhim(maphim);
         N4=0;
      }
      if (maphim==4)
      {
         LOOP=0;
      }
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1 && maphim!=16)
   {
      show_Date();
      maphim=quet_phim();
      if (N3==1)
      {
         if (maphim==14 || maphim==1 || maphim==2)
         {
            N4=DichPhim(maphim);
         }
      }
      if (N3==0)
      {
         if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11)
         {
            N4=DichPhim(maphim);
         }
      }
      if (maphim==4)
      {
         LOOP=0;
      }
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);Thang=N3*10+N4;}
   while (LOOP==1 && maphim!=16)
   {
      show_Date();
      maphim=quet_phim();
      if (Thang!=2)
      {
         if (maphim==1 || maphim==2 || maphim==3||maphim==14)
         {
            N5=DichPhim(maphim);
            if (N5!=0)
            {
               N6 = 0;
            }
            else N6=1;
         }
      }
      else 
      {
         if (maphim==1 || maphim==2 ||maphim==14)
         {
            N5=DichPhim(maphim);
            if (N5!=0)
            {
               N6 = 0;
            }
            else N6=1;
         }
      }
      if (maphim==4)
      {
         LOOP=0;
      }
   } 
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1 && maphim!=16)
   {
      show_Date();
      maphim=quet_phim();
      if (Thang==1||Thang==3||Thang==5||Thang==7||Thang==8||Thang==10||Thang==12)
      {
         if (N5==3)
         {
            if (maphim==1 || maphim==14)
            {
               N6=DichPhim(maphim);
            }
         }
         if (N5==2||N5==1)
         {
            if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11||maphim==14)
            {
               N6=DichPhim(maphim);
            }
         }
         if (N5==0)
         {
            if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11)
            {
               N6=DichPhim(maphim);
            }
         }
      }
      if (Thang==4||Thang==6||Thang==9||Thang==11)
      {
         if (N5==3)
         {
            if (maphim==14)
            {
               N6=DichPhim(maphim);
            }
         }
         if (N5==2||N5==1)
         {
            if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11||maphim==14)
            {
               N6=DichPhim(maphim);
            }
         }
         if (N5==0)
         {
            if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11)
            {
               N6=DichPhim(maphim);
            }
         }
      }
      if (Thang==2)
      {
         if ((Nam+2000)%4==0&&(Nam+2000)%100!=0)
         {
            if (N5==2||N5==1)
            {
               if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11||maphim==14)
               {
                  N6=DichPhim(maphim);
               }
            }
            if (N5==0)
            {
               if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11)
               {
                  N6=DichPhim(maphim);
               }
            }
         }
         else 
         {
            if (N5==2)
            {
               if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10||maphim==14)
               {
                  N6=DichPhim(maphim);
               }
            }
            if (N5==1)
            {
               if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11||maphim==14)
               {
                  N6=DichPhim(maphim);
               }
            }
            if (N5==0)
            {
               if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11)
               {
                  N6=DichPhim(maphim);
               }
            }
         }
      }
      if (maphim==4)
      {
         LOOP=0;
      }
   }
   if (LOOP==1)
   {
      maphim=0xff;
      Ngay=N5*10+N6;
      mytime = RTC_Get();
      mytime->year = Nam;
      mytime->month = Thang;
      mytime->day = Ngay;
      RTC_Set(mytime);
   }
   else 
   {
      lcd_clear();
      lcd_gotoxy(2, 1);
      lcd_putc("CANCEL");
   }
}
void SET_BT()
{
   delay_ms(500);
   LOOP=1;
   maphim=0xff;
   N1=0,N2=0,N3=0,N4=0;
   while (LOOP==1&&maphim!=16){
      show_BT();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim == 14){
         N1=DichPhim(maphim);
      }
      if (maphim==4){
         LOOP=0;
      }
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1&&maphim!=16){
      show_BT();
      maphim=quet_phim();
      if (N1==0 || N1==1){
         if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11 || maphim==14){
            N2=DichPhim(maphim);
         }
      }
      if (N1 == 2){
         if (maphim==1 || maphim==2 || maphim==3 || maphim == 14){
            N2=DichPhim(maphim);
         }
      }
      if (maphim==4){LOOP=0;}
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1&&maphim!=16){
      show_BT();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim == 14){
         N3=DichPhim(maphim);
      }
      
      if (maphim==4){LOOP=0;}
   }
   if (LOOP==1) {maphim=0xff;delay_ms(500);}
   while (LOOP==1 && maphim!=16){
      show_BT();
      maphim=quet_phim();
      if (maphim==1 || maphim==2 || maphim==3 || maphim==5 || maphim==6 || maphim==7 || maphim==9 || maphim==10 || maphim==11 || maphim==14){
         N4=DichPhim(maphim);
      }
      if (maphim==4){LOOP=0;}
   }
   if (LOOP==1){
      GioBT[ctrl_Menu-1]=N1*10+N2;
      PhutBT[ctrl_Menu-1]=N3*10+N4;
   }
   else {
      lcd_clear();
      lcd_gotoxy(1, 1);
      lcd_putc("CANCELED");
      delay_ms(2000);
   }
}
void show() 
{
   lcd_gotoxy(1, 1);
   lcd_putc("TIME: ");
   lcd_gotoxy(7, 1); 
   printf(lcd_putc, "%02ld:%02ld:%02ld", Gio,Phut,Giay);
   lcd_gotoxy(1, 2);
   lcd_putc("DATE: ");
   lcd_gotoxy(7, 2);
   printf(lcd_putc, "%02ld/%02ld/20%02ld", Ngay, Thang, Nam);
}

void MENU()
{
   delay_ms(100);
   ctrl_Menu=1;
   maphim=0xff;
   while (ctrl_Menu!=0){
      Menu_case();
      maphim=0xff;
      maphim = quet_phim();
      lcd_gotoxy(2, 1);
      lcd_putc("ALARM 1: ");
      if (BT[0]==0)
      {
         lcd_putc("OFF   ");
      }
      else printf(lcd_putc, "%02ld:%02ld", GioBT[0],PhutBT[0]);
      lcd_gotoxy(2, 2);
      lcd_putc("ALARM 2: ");
      if (BT[1]==0)
      {
         lcd_putc("OFF   ");
      }
      else printf(lcd_putc, "%02ld:%02ld", GioBT[1],PhutBT[1]);
      if (maphim==8){
         if (ctrl_Menu==1){
            ctrl_Menu=2;
         }
         else ctrl_Menu=1;
      }
      if (maphim==12)
      {
         if (ctrl_Menu==1)
         {
            if (BT[0]==0)
            {
               BT[0]=1;
            }
            else BT[0]=0;
         }
         else
         {
            if (BT[1]==0)
            {
               BT[1]=1;
            }
            else BT[1]=0;
         }
      }
      if (maphim==16){
         lcd_clear();
         SET_BT();
         lcd_clear();
         maphim=0xff;
      }
      if (maphim==4){
         ctrl_Menu=0;
      }
   }
}

void CHECKBT()
{
   for (i=0;i<=1;i++)
   {
      if (BT[i]==1)
      {
         if (GioBT[i]==Gio&&PhutBT[i]==Phut&&Giay==0)
         {
            maphim=0xff;
            OUTPUT_HIGH(pin_C0);
            while (maphim==0xff)
            {
               lcd_gotoxy(2, 1);
               lcd_putc("TROI SANG ROI");
               maphim=quet_phim();
               delay_ms(100);
            }
            OUTPUT_LOW(pin_C0);
         }
      }
   }
}

void main()
{
   lcd_init(); 
   lcd_clear();
   while (true)
   {
      mytime = RTC_Get();
      Gio = mytime->hours;
      Phut = mytime->minutes;
      Giay = mytime->seconds;
      Future = mytime->seconds;
      Ngay = mytime->day;
      Thang = mytime->month;
      Nam = mytime->year;
      CHECKBT();
      show();
      while (Future==Giay)
      {
         mytime = RTC_Get();
         Future = mytime->seconds;
         delay_ms(50);
         maphim=quet_phim();
         if (maphim==4)
         {
            lcd_clear();
            MENU();
            lcd_clear();
         }
         if (maphim==13)
         {
            lcd_clear();
            SET_TIME();
            lcd_clear();
         }
         if (maphim==15)
         {
            lcd_clear();
            SET_DATE();
            lcd_clear();
         }
      }
      lcd_clear();
   }
}


