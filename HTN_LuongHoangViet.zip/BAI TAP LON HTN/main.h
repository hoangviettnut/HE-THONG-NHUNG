#include <16F877A.h>
#device ADC=10
#use delay(crystal=20000000)

